
 ==============================================================

          Exeinfo PE v0.0.4.1 III - 902 + 35 signatures

           *with partial support for 64 bit PE files


 ==============================================================


included : 

- 0 skins
- language file neutral - v0.0.4.1 
- language file China Big5 v0.0.4.1 
- Ext_detector.dll - ver.3.2.0  ( with : 320 NON EXE SIGNATURES )


plugin :

  none


 added :

 - GUI visible changed
 - internal Skins changed
 - Now detect : Obsidium 32 / 64 v1.5.4.6 ( 2015.10.21 )
 - many detection fixes




Exeinfo NON GUI - Console Mode info 

if you need change log file "!ExEinfo-Multiscan.log" to your path/file

try : exeinfope.exe FileName* /s /log:C:\MyLogFile.txt
  For long file path/names 
try : exeinfope.exe FileName* /s /log:"C:\My Dir 1 2 3\LogFile.txt"






   A.S.L  (c) www.exeinfo.xn.pl - 2015.12.15






